Please report security issues directly over email to me@adamj.eu
